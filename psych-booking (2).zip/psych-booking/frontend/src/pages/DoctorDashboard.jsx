import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '../hooks/useAuth.jsx';
import api from '../utils/api.js';

function DoctorStatRow({ appointments }) {
  const pending   = appointments.filter(a => a.status === 'pending').length;
  const confirmed = appointments.filter(a => a.status === 'confirmed').length;
  const today = appointments.filter(a => {
    const d = new Date(a.date);
    const now = new Date();
    return d.toDateString() === now.toDateString();
  }).length;

  return (
    <div className="stat-row">
      <div className="stat-card">
        <div className="stat-value">{appointments.length}</div>
        <div className="stat-label">Total Patients</div>
      </div>
      <div className="stat-card">
        <div className="stat-value">{pending}</div>
        <div className="stat-label">Awaiting Confirmation</div>
      </div>
      <div className="stat-card">
        <div className="stat-value">{confirmed}</div>
        <div className="stat-label">Confirmed</div>
      </div>
      <div className="stat-card">
        <div className="stat-value">{today}</div>
        <div className="stat-label">Today's Appointments</div>
      </div>
    </div>
  );
}

function AppointmentsTab() {
  const qc = useQueryClient();
  const [notesMap, setNotesMap] = useState({});
  const [filter, setFilter] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['doctor-appointments', filter],
    queryFn: () => api.get(`/appointments/doctor${filter ? `?status=${filter}` : ''}`).then(r => r.data)
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, payload }) => api.put(`/appointments/${id}`, payload),
    onSuccess: () => qc.invalidateQueries(['doctor-appointments'])
  });

  const handleUpdate = (id, status) => {
    const notes = notesMap[id] || undefined;
    updateMutation.mutate({ id, payload: { status, notes } });
  };

  if (isLoading) return <div className="loading-page"><div className="spinner spinner-dark" /><span>Loading appointments...</span></div>;

  const appointments = data?.appointments || [];

  const FILTERS = [
    { value: '', label: 'All' },
    { value: 'pending', label: 'Pending' },
    { value: 'confirmed', label: 'Confirmed' },
    { value: 'completed', label: 'Completed' },
    { value: 'cancelled', label: 'Cancelled' }
  ];

  return (
    <div className="card">
      <div className="card-header">
        <h2>Patient Appointments</h2>
        <div style={{ display: 'flex', gap: 6 }}>
          {FILTERS.map(f => (
            <button
              key={f.value}
              className={`btn btn-sm ${filter === f.value ? 'btn-primary' : 'btn-ghost'}`}
              onClick={() => setFilter(f.value)}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {appointments.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🗓️</div>
          <p>No appointments found.</p>
        </div>
      ) : appointments.map(a => (
        <div key={a._id} className="appt-card">
          <div className="appt-header">
            <div>
              <h3>{a.patient?.name}</h3>
              <div className="meta">📧 {a.patient?.email}</div>
              {a.patient?.phone && <div className="meta">📞 {a.patient.phone}</div>}
              <div className="meta">
                📅 {new Date(a.date).toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                &nbsp; 🕐 {a.time}
              </div>
              <div className="meta">📝 Reason: {a.reason}</div>
            </div>
            <span className={`badge badge-${a.status}`}>{a.status}</span>
          </div>

          {a.notes && (
            <div className="doctor-notes">
              <strong>Clinical Notes</strong>
              {a.notes}
            </div>
          )}

          <textarea
            className="notes-textarea"
            placeholder="Add or update clinical notes..."
            defaultValue={a.notes || ''}
            onChange={e => setNotesMap(prev => ({ ...prev, [a._id]: e.target.value }))}
          />

          {a.status !== 'cancelled' && a.status !== 'completed' && (
            <div className="actions">
              {a.status === 'pending' && (
                <button
                  className="btn btn-sm btn-success"
                  onClick={() => handleUpdate(a._id, 'confirmed')}
                  disabled={updateMutation.isPending}
                >
                  ✓ Confirm
                </button>
              )}
              {(a.status === 'pending' || a.status === 'confirmed') && (
                <button
                  className="btn btn-sm btn-primary"
                  onClick={() => handleUpdate(a._id, 'completed')}
                  disabled={updateMutation.isPending}
                >
                  Mark Completed
                </button>
              )}
              <button
                className="btn btn-sm btn-danger"
                onClick={() => { if (window.confirm('Cancel this appointment?')) handleUpdate(a._id, 'cancelled'); }}
                disabled={updateMutation.isPending}
              >
                Cancel
              </button>
              {notesMap[a._id] && (
                <button
                  className="btn btn-sm btn-ghost"
                  onClick={() => updateMutation.mutate({ id: a._id, payload: { status: a.status, notes: notesMap[a._id] } })}
                  disabled={updateMutation.isPending}
                >
                  💾 Save Notes
                </button>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function PrescribeTab() {
  const qc = useQueryClient();

  const { data } = useQuery({
    queryKey: ['doctor-appointments-completed'],
    queryFn: () => api.get('/appointments/doctor?status=completed').then(r => r.data)
  });
  const completedAppts = data?.appointments || [];

  const [selectedAppt, setSelectedAppt] = useState(null);
  const [medications, setMedications] = useState([{ name: '', dosage: '', frequency: '', duration: '' }]);
  const [instructions, setInstructions] = useState('');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const prescribeMutation = useMutation({
    mutationFn: (payload) => api.post('/prescriptions', payload),
    onSuccess: () => {
      qc.invalidateQueries(['doctor-prescriptions']);
      setSuccess('Prescription issued successfully!');
      setError('');
      setSelectedAppt(null);
      setMedications([{ name: '', dosage: '', frequency: '', duration: '' }]);
      setInstructions('');
      setTimeout(() => setSuccess(''), 4000);
    },
    onError: (err) => {
      setError(err.response?.data?.error || 'Failed to issue prescription');
    }
  });

  const updateMed = (index, field, value) => {
    const updated = [...medications];
    updated[index][field] = value;
    setMedications(updated);
  };

  const addMed = () => setMedications([...medications, { name: '', dosage: '', frequency: '', duration: '' }]);
  const removeMed = (i) => setMedications(medications.filter((_, idx) => idx !== i));

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!selectedAppt) return setError('Please select a patient/appointment');
    if (medications.some(m => !m.name || !m.dosage || !m.frequency || !m.duration)) {
      return setError('Please fill in all medication fields');
    }
    prescribeMutation.mutate({
      patient: selectedAppt.patient._id,
      appointment: selectedAppt._id,
      medications,
      instructions
    });
  };

  return (
    <div className="card">
      <div className="card-header">
        <h2>Issue Prescription</h2>
      </div>
      {success && <div className="alert alert-success">✓ {success}</div>}
      {error && <div className="alert alert-error">⚠ {error}</div>}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Select Completed Appointment</label>
          <select
            value={selectedAppt?._id || ''}
            onChange={e => setSelectedAppt(completedAppts.find(a => a._id === e.target.value) || null)}
          >
            <option value="">Choose a patient/appointment...</option>
            {completedAppts.map(a => (
              <option key={a._id} value={a._id}>
                {a.patient?.name} — {new Date(a.date).toLocaleDateString('en-IN')} at {a.time}
              </option>
            ))}
          </select>
        </div>

        {completedAppts.length === 0 && (
          <div className="alert alert-error" style={{ marginBottom: 20 }}>
            No completed appointments found. Mark an appointment as completed first.
          </div>
        )}

        <div style={{ marginBottom: 16 }}>
          <label style={{ display: 'block', fontWeight: 500, marginBottom: 10, fontSize: '0.85rem', color: 'var(--charcoal-soft)' }}>
            Medications
          </label>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr auto', gap: 8, marginBottom: 6 }}>
            {['Drug Name', 'Dosage', 'Frequency', 'Duration', ''].map((h, i) => (
              <div key={i} style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.4px', padding: '0 4px' }}>{h}</div>
            ))}
          </div>
          {medications.map((m, i) => (
            <div className="med-row" key={i}>
              <input placeholder="e.g. Sertraline" value={m.name} onChange={e => updateMed(i, 'name', e.target.value)} required />
              <input placeholder="e.g. 50mg" value={m.dosage} onChange={e => updateMed(i, 'dosage', e.target.value)} required />
              <input placeholder="e.g. Once daily" value={m.frequency} onChange={e => updateMed(i, 'frequency', e.target.value)} required />
              <input placeholder="e.g. 30 days" value={m.duration} onChange={e => updateMed(i, 'duration', e.target.value)} required />
              <button type="button" className="remove-btn" onClick={() => removeMed(i)} disabled={medications.length === 1}>×</button>
            </div>
          ))}
          <button type="button" className="btn btn-sm btn-ghost" onClick={addMed} style={{ marginTop: 4 }}>
            + Add Medication
          </button>
        </div>

        <div className="form-group">
          <label>Special Instructions (Optional)</label>
          <textarea
            placeholder="e.g. Take after meals. Avoid alcohol. Return in 4 weeks for follow-up."
            value={instructions}
            onChange={e => setInstructions(e.target.value)}
          />
        </div>

        <button
          type="submit"
          className="btn btn-primary"
          disabled={prescribeMutation.isPending || !selectedAppt}
        >
          {prescribeMutation.isPending ? <><span className="spinner" /> Issuing...</> : 'Issue Prescription →'}
        </button>
      </form>
    </div>
  );
}

function PrescriptionsHistoryTab() {
  const { data: rxs = [], isLoading } = useQuery({
    queryKey: ['doctor-prescriptions'],
    queryFn: () => api.get('/prescriptions/doctor').then(r => r.data)
  });

  if (isLoading) return <div className="loading-page"><div className="spinner spinner-dark" /><span>Loading...</span></div>;

  return (
    <div className="card">
      <div className="card-header">
        <h2>Issued Prescriptions</h2>
        <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{rxs.length} total</span>
      </div>
      {rxs.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📋</div>
          <p>No prescriptions issued yet.</p>
        </div>
      ) : rxs.map(rx => (
        <div key={rx._id} className="rx-card">
          <div className="rx-header">
            <div>
              <h3>{rx.patient?.name}</h3>
              <div className="rx-date">
                {rx.patient?.email} · Issued {new Date(rx.issuedAt).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })}
              </div>
            </div>
          </div>
          <ul className="medication-list">
            {rx.medications.map((m, i) => (
              <li key={i}>
                <span className="med-name">{m.name}</span>
                <span className="med-details">{m.dosage} · {m.frequency} · {m.duration}</span>
              </li>
            ))}
          </ul>
          {rx.instructions && (
            <div className="rx-instructions">
              <strong>Instructions: </strong>{rx.instructions}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

const TABS = [
  { id: 'appointments', label: 'Appointments' },
  { id: 'prescribe', label: '+ Issue Prescription' },
  { id: 'history', label: 'Prescription History' }
];

export default function DoctorDashboard() {
  const { user, logout } = useAuth();
  const [tab, setTab] = useState('appointments');

  const { data } = useQuery({
    queryKey: ['doctor-appointments', ''],
    queryFn: () => api.get('/appointments/doctor').then(r => r.data)
  });
  const appointments = data?.appointments || [];

  const initials = user?.name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || 'DR';

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div className="logo">MindCare</div>
        <div className="header-right">
          <div className="user-pill">
            <div className="avatar" style={{ background: 'var(--sage-dark)' }}>{initials}</div>
            <span className="user-name">{user?.name}</span>
            <span className="role-badge">Doctor</span>
          </div>
          <button className="btn btn-sm btn-ghost" onClick={logout}>Sign Out</button>
        </div>
      </header>

      <nav className="dashboard-nav">
        {TABS.map(t => (
          <button key={t.id} className={tab === t.id ? 'active' : ''} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </nav>

      <div className="dashboard-content">
        <DoctorStatRow appointments={appointments} />
        {tab === 'appointments' && <AppointmentsTab />}
        {tab === 'prescribe' && <PrescribeTab />}
        {tab === 'history' && <PrescriptionsHistoryTab />}
      </div>
    </div>
  );
}
