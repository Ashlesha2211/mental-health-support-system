import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { useAuth } from '../hooks/useAuth.jsx';
import api from '../utils/api.js';

function StatRow({ appointments }) {
  const pending   = appointments.filter(a => a.status === 'pending').length;
  const confirmed = appointments.filter(a => a.status === 'confirmed').length;
  const completed = appointments.filter(a => a.status === 'completed').length;
  return (
    <div className="stat-row">
      <div className="stat-card">
        <div className="stat-value">{appointments.length}</div>
        <div className="stat-label">Total Appointments</div>
      </div>
      <div className="stat-card">
        <div className="stat-value">{pending}</div>
        <div className="stat-label">Pending</div>
      </div>
      <div className="stat-card">
        <div className="stat-value">{confirmed}</div>
        <div className="stat-label">Confirmed</div>
      </div>
      <div className="stat-card">
        <div className="stat-value">{completed}</div>
        <div className="stat-label">Completed</div>
      </div>
    </div>
  );
}

function BookTab() {
  const qc = useQueryClient();
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const { data: doctors = [] } = useQuery({
    queryKey: ['doctors'],
    queryFn: () => api.get('/doctors').then(r => r.data)
  });

  const bookMutation = useMutation({
    mutationFn: (data) => api.post('/appointments', data),
    onSuccess: () => {
      qc.invalidateQueries(['appointments']);
      setSuccess('Appointment booked successfully!');
      setError('');
      reset();
      setTimeout(() => setSuccess(''), 4000);
    },
    onError: (err) => {
      setError(err.response?.data?.error || 'Booking failed');
      setSuccess('');
    }
  });

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="card">
      <div className="card-header">
        <h2>Book an Appointment</h2>
      </div>
      {success && <div className="alert alert-success">✓ {success}</div>}
      {error && <div className="alert alert-error">⚠ {error}</div>}
      <form onSubmit={handleSubmit(d => bookMutation.mutate(d))}>
        <div className="form-group">
          <label>Select Psychiatrist</label>
          <select {...register('doctor', { required: 'Please select a doctor' })}>
            <option value="">Choose a doctor...</option>
            {doctors.map(d => (
              <option key={d._id} value={d._id}>{d.name} — {d.specialty}</option>
            ))}
          </select>
          {errors.doctor && <div className="form-error">⚠ {errors.doctor.message}</div>}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div className="form-group">
            <label>Preferred Date</label>
            <input type="date" min={today} {...register('date', { required: 'Date is required' })} />
            {errors.date && <div className="form-error">⚠ {errors.date.message}</div>}
          </div>
          <div className="form-group">
            <label>Preferred Time</label>
            <input type="time" {...register('time', { required: 'Time is required' })} />
            {errors.time && <div className="form-error">⚠ {errors.time.message}</div>}
          </div>
        </div>
        <div className="form-group">
          <label>Reason for Visit</label>
          <textarea
            placeholder="Briefly describe your concern or symptoms (min 5 characters)..."
            {...register('reason', {
              required: 'Reason is required',
              minLength: { value: 5, message: 'Please provide more detail' }
            })}
          />
          {errors.reason && <div className="form-error">⚠ {errors.reason.message}</div>}
        </div>
        <button
          type="submit"
          className="btn btn-primary"
          disabled={bookMutation.isPending}
        >
          {bookMutation.isPending ? <><span className="spinner" /> Booking...</> : 'Confirm Booking →'}
        </button>
      </form>
    </div>
  );
}

function AppointmentsTab() {
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ['appointments'],
    queryFn: () => api.get('/appointments/my').then(r => r.data)
  });

  const cancelMutation = useMutation({
    mutationFn: (id) => api.patch(`/appointments/${id}/cancel`),
    onSuccess: () => qc.invalidateQueries(['appointments'])
  });

  if (isLoading) return <div className="loading-page"><div className="spinner spinner-dark" /><span>Loading appointments...</span></div>;

  const appointments = data?.appointments || [];

  return (
    <div className="card">
      <div className="card-header">
        <h2>My Appointments</h2>
        <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{appointments.length} total</span>
      </div>
      {appointments.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🗓️</div>
          <p>No appointments yet. Book your first one!</p>
        </div>
      ) : appointments.map(a => (
        <div key={a._id} className="appt-card">
          <div className="appt-header">
            <div>
              <h3>Dr. {a.doctor?.name}</h3>
              <div className="meta">🩺 {a.doctor?.specialty}</div>
              <div className="meta">
                📅 {new Date(a.date).toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                &nbsp; 🕐 {a.time}
              </div>
              <div className="meta">📝 {a.reason}</div>
            </div>
            <span className={`badge badge-${a.status}`}>{a.status}</span>
          </div>
          {a.notes && (
            <div className="doctor-notes">
              <strong>Doctor's Notes</strong>
              {a.notes}
            </div>
          )}
          {['pending', 'confirmed'].includes(a.status) && (
            <div className="actions">
              <button
                className="btn btn-sm btn-danger"
                onClick={() => { if (window.confirm('Cancel this appointment?')) cancelMutation.mutate(a._id); }}
                disabled={cancelMutation.isPending}
              >
                Cancel Appointment
              </button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function PrescriptionsTab() {
  const { data, isLoading } = useQuery({
    queryKey: ['prescriptions'],
    queryFn: () => api.get('/prescriptions/my').then(r => r.data)
  });

  if (isLoading) return <div className="loading-page"><div className="spinner spinner-dark" /><span>Loading prescriptions...</span></div>;

  const prescriptions = data?.prescriptions || [];

  return (
    <div className="card">
      <div className="card-header">
        <h2>My Prescriptions</h2>
        <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{prescriptions.length} total</span>
      </div>
      {prescriptions.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">💊</div>
          <p>No prescriptions yet.</p>
        </div>
      ) : prescriptions.map(rx => (
        <div key={rx._id} className="rx-card">
          <div className="rx-header">
            <div>
              <h3>Prescribed by Dr. {rx.doctor?.name}</h3>
              <div className="rx-date">
                {rx.doctor?.specialty} · Issued {new Date(rx.issuedAt).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })}
              </div>
            </div>
            <span className="badge badge-confirmed">Active</span>
          </div>
          <ul className="medication-list">
            {rx.medications.map((m, i) => (
              <li key={i}>
                <span className="med-name">{m.name}</span>
                <span className="med-details">{m.dosage} · {m.frequency} · {m.duration}</span>
              </li>
            ))}
          </ul>
          {rx.instructions && (
            <div className="rx-instructions">
              <strong>Instructions: </strong>{rx.instructions}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

const TABS = [
  { id: 'book', label: '+ Book Appointment' },
  { id: 'appointments', label: 'My Appointments' },
  { id: 'prescriptions', label: 'My Prescriptions' }
];

export default function PatientDashboard() {
  const { user, logout } = useAuth();
  const [tab, setTab] = useState('book');

  const { data } = useQuery({
    queryKey: ['appointments'],
    queryFn: () => api.get('/appointments/my').then(r => r.data)
  });
  const appointments = data?.appointments || [];

  const initials = user?.name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || 'P';

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div className="logo">MindCare</div>
        <div className="header-right">
          <div className="user-pill">
            <div className="avatar">{initials}</div>
            <span className="user-name">{user?.name}</span>
            <span className="role-badge">Patient</span>
          </div>
          <button className="btn btn-sm btn-ghost" onClick={logout}>Sign Out</button>
        </div>
      </header>

      <nav className="dashboard-nav">
        {TABS.map(t => (
          <button key={t.id} className={tab === t.id ? 'active' : ''} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </nav>

      <div className="dashboard-content">
        <StatRow appointments={appointments} />
        {tab === 'book' && <BookTab />}
        {tab === 'appointments' && <AppointmentsTab />}
        {tab === 'prescriptions' && <PrescriptionsTab />}
      </div>
    </div>
  );
}
