import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';

export default function Login() {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const { login } = useAuth();
  const nav = useNavigate();
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  const onSubmit = async (data) => {
    setServerError('');
    setLoading(true);
    try {
      const user = await login(data.email, data.password);
      nav(user.role === 'doctor' ? '/doctor' : '/patient', { replace: true });
    } catch (err) {
      setServerError(err.response?.data?.error || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-left">
        <div className="brand">MindCare</div>
        <h1>Welcome back</h1>
        <p>Sign in to manage your appointments and continue your care journey.</p>
        <div className="features">
          <div className="feat-item">
            <div className="feat-icon">🗓️</div>
            <span>View upcoming appointments</span>
          </div>
          <div className="feat-item">
            <div className="feat-icon">💊</div>
            <span>Access your prescriptions</span>
          </div>
          <div className="feat-item">
            <div className="feat-icon">🔒</div>
            <span>Secure, encrypted health data</span>
          </div>
        </div>
      </div>

      <div className="auth-right">
        <div className="auth-box">
          <h2>Sign In</h2>
          <p className="subtitle">Enter your credentials to access your account</p>

          {serverError && (
            <div className="alert alert-error">⚠ {serverError}</div>
          )}

          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="form-group">
              <label>Email Address</label>
              <input
                type="email"
                placeholder="you@example.com"
                {...register('email', {
                  required: 'Email is required',
                  pattern: { value: /^\S+@\S+\.\S+$/, message: 'Enter a valid email' }
                })}
              />
              {errors.email && <div className="form-error">⚠ {errors.email.message}</div>}
            </div>

            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                placeholder="Your password"
                {...register('password', { required: 'Password is required' })}
              />
              {errors.password && <div className="form-error">⚠ {errors.password.message}</div>}
            </div>

            <button type="submit" className="btn btn-primary btn-full" disabled={loading}>
              {loading ? <><span className="spinner" /> Signing in...</> : 'Sign In →'}
            </button>
          </form>

          <div className="auth-footer">
            Don't have an account? <Link to="/register">Create one</Link>
          </div>
          <div className="auth-footer" style={{ marginTop: 8 }}>
            <Link to="/">← Back to Home</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
