import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';

export default function Register() {
  const { register, handleSubmit, watch, formState: { errors } } = useForm();
  const { register: authRegister } = useAuth();
  const nav = useNavigate();
  const [role, setRole] = useState('patient');
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  const onSubmit = async (data) => {
    setServerError('');
    setLoading(true);
    try {
      const user = await authRegister({ ...data, role });
      nav(user.role === 'doctor' ? '/doctor' : '/patient', { replace: true });
    } catch (err) {
      setServerError(err.response?.data?.error ||
        err.response?.data?.details?.[0]?.message ||
        'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-left">
        <div className="brand">MindCare</div>
        <h1>Start your care journey</h1>
        <p>Join thousands of patients and psychiatrists on a platform built around trust, privacy, and wellbeing.</p>
        <div className="features">
          <div className="feat-item">
            <div className="feat-icon">✅</div>
            <span>Free to join, no hidden fees</span>
          </div>
          <div className="feat-item">
            <div className="feat-icon">🩺</div>
            <span>Verified psychiatrists only</span>
          </div>
          <div className="feat-item">
            <div className="feat-icon">📋</div>
            <span>Full medical record history</span>
          </div>
        </div>
      </div>

      <div className="auth-right">
        <div className="auth-box">
          <h2>Create Account</h2>
          <p className="subtitle">Choose your role to get started</p>

          <div className="role-toggle">
            <button
              type="button"
              className={role === 'patient' ? 'active' : ''}
              onClick={() => setRole('patient')}
            >
              🧑 Patient
            </button>
            <button
              type="button"
              className={role === 'doctor' ? 'active' : ''}
              onClick={() => setRole('doctor')}
            >
              🩺 Doctor
            </button>
          </div>

          {serverError && (
            <div className="alert alert-error">⚠ {serverError}</div>
          )}

          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="form-group">
              <label>Full Name</label>
              <input
                placeholder={role === 'doctor' ? 'Dr. Firstname Lastname' : 'Your full name'}
                {...register('name', {
                  required: 'Name is required',
                  minLength: { value: 2, message: 'Name too short' }
                })}
              />
              {errors.name && <div className="form-error">⚠ {errors.name.message}</div>}
            </div>

            <div className="form-group">
              <label>Email Address</label>
              <input
                type="email"
                placeholder="you@example.com"
                {...register('email', {
                  required: 'Email is required',
                  pattern: { value: /^\S+@\S+\.\S+$/, message: 'Enter a valid email' }
                })}
              />
              {errors.email && <div className="form-error">⚠ {errors.email.message}</div>}
            </div>

            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                placeholder="Min 8 chars, 1 uppercase, 1 number"
                {...register('password', {
                  required: 'Password is required',
                  minLength: { value: 8, message: 'Password must be at least 8 characters' },
                  pattern: {
                    value: /^(?=.*[A-Z])(?=.*\d)/,
                    message: 'Must contain at least one uppercase letter and one number'
                  }
                })}
              />
              {errors.password && <div className="form-error">⚠ {errors.password.message}</div>}
            </div>

            {role === 'doctor' && (
              <div className="form-group">
                <label>Specialty</label>
                <input
                  placeholder="e.g. Adult Psychiatry, Child Psychiatry"
                  {...register('specialty', {
                    required: role === 'doctor' ? 'Specialty is required for doctors' : false
                  })}
                />
                {errors.specialty && <div className="form-error">⚠ {errors.specialty.message}</div>}
              </div>
            )}

            <button type="submit" className="btn btn-primary btn-full" disabled={loading}>
              {loading ? <><span className="spinner" /> Creating account...</> : `Create ${role === 'doctor' ? 'Doctor' : 'Patient'} Account →`}
            </button>
          </form>

          <div className="auth-footer">
            Already have an account? <Link to="/login">Sign in</Link>
          </div>
          <div className="auth-footer" style={{ marginTop: 8 }}>
            <Link to="/">← Back to Home</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
