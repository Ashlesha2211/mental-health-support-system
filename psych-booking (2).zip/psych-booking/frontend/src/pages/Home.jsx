import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';

export default function Home() {
  const { user } = useAuth();

  const features = [
    { icon: '🗓️', title: 'Easy Booking', desc: 'Schedule appointments with certified psychiatrists in minutes. Choose your preferred time and specialist.' },
    { icon: '💊', title: 'Digital Prescriptions', desc: 'Access your prescriptions securely online. Never lose a prescription again — it\'s always in your account.' },
    { icon: '🔒', title: 'Private & Secure', desc: 'Your health data is encrypted and protected. We follow strict medical data privacy standards.' },
    { icon: '🩺', title: 'Qualified Doctors', desc: 'All our psychiatrists are board-certified with verified credentials and years of clinical experience.' },
    { icon: '📋', title: 'Patient Records', desc: 'Doctors maintain complete visit histories and clinical notes for continuity of care.' },
    { icon: '📱', title: 'Fully Responsive', desc: 'Access your appointments and prescriptions from any device, anywhere, any time.' }
  ];

  return (
    <div>
      <div className="home-hero">
        <nav className="hero-nav">
          <div className="logo">MindCare</div>
          <div className="nav-links">
            {user ? (
              <Link
                to={user.role === 'doctor' ? '/doctor' : '/patient'}
                className="hero-btn-primary"
                style={{ padding: '10px 20px', fontSize: '0.875rem' }}
              >
                Go to Dashboard →
              </Link>
            ) : (
              <>
                <Link to="/login" className="hero-btn-outline" style={{ padding: '10px 20px', fontSize: '0.875rem' }}>Sign In</Link>
                <Link to="/register" className="hero-btn-primary" style={{ padding: '10px 20px', fontSize: '0.875rem' }}>Get Started</Link>
              </>
            )}
          </div>
        </nav>

        <div className="hero-body">
          <div className="hero-text">
            <div className="tagline">Mental Health Care</div>
            <h1>
              Your mind deserves <em>expert</em> attention
            </h1>
            <p>
              MindCare connects patients with certified psychiatrists for seamless appointment booking,
              digital prescriptions, and continuous care — all in one secure platform.
            </p>
            <div className="hero-actions">
              <Link to="/register" className="hero-btn-primary">
                Book Your First Appointment →
              </Link>
              <Link to="/login" className="hero-btn-outline">
                Sign In
              </Link>
            </div>
          </div>
        </div>
      </div>

      <section className="home-features">
        <h2>Everything you need for mental health care</h2>
        <p className="section-sub">A complete platform for patients and psychiatrists alike</p>
        <div className="features-grid">
          {features.map((f, i) => (
            <div className="feature-card" key={i}>
              <div className="icon">{f.icon}</div>
              <h3>{f.title}</h3>
              <p>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="home-footer">
        <p>© 2025 <span>MindCare</span>. Built with MERN Stack. All rights reserved.</p>
      </footer>
    </div>
  );
}
