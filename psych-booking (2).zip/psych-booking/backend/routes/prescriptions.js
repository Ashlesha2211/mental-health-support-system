const router = require('express').Router();
const Prescription = require('../models/Prescription');
const { auth, requireRole } = require('../middleware/auth');
const { prescriptionValidator } = require('../validators');

// POST /api/prescriptions — doctor issues
router.post('/', auth, requireRole('doctor'), prescriptionValidator, async (req, res, next) => {
  try {
    const rx = await Prescription.create({ ...req.body, doctor: req.user._id });
    const populated = await rx.populate([
      { path: 'patient', select: 'name email' },
      { path: 'appointment', select: 'date time' }
    ]);
    res.status(201).json(populated);
  } catch (err) { next(err); }
});

// GET /api/prescriptions/my — patient's prescriptions
router.get('/my', auth, requireRole('patient'), async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const [prescriptions, total] = await Promise.all([
      Prescription.find({ patient: req.user._id })
        .populate('doctor', 'name specialty')
        .populate('appointment', 'date time')
        .sort({ issuedAt: -1 })
        .skip(skip)
        .limit(limit),
      Prescription.countDocuments({ patient: req.user._id })
    ]);

    res.json({ prescriptions, total, page, pages: Math.ceil(total / limit) });
  } catch (err) { next(err); }
});

// GET /api/prescriptions/doctor — doctor's issued prescriptions
router.get('/doctor', auth, requireRole('doctor'), async (req, res, next) => {
  try {
    const rxs = await Prescription.find({ doctor: req.user._id })
      .populate('patient', 'name email')
      .populate('appointment', 'date time')
      .sort({ issuedAt: -1 })
      .limit(50);
    res.json(rxs);
  } catch (err) { next(err); }
});

// GET /api/prescriptions/:id — get single prescription
router.get('/:id', auth, async (req, res, next) => {
  try {
    const rx = await Prescription.findById(req.params.id)
      .populate('doctor', 'name specialty')
      .populate('patient', 'name email')
      .populate('appointment', 'date time');

    if (!rx) return res.status(404).json({ error: 'Prescription not found' });

    // Access control: only the patient or issuing doctor
    const userId = req.user._id.toString();
    if (rx.patient._id.toString() !== userId && rx.doctor._id.toString() !== userId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json(rx);
  } catch (err) { next(err); }
});

module.exports = router;
