const router = require('express').Router();
const Appointment = require('../models/Appointment');
const { auth, requireRole } = require('../middleware/auth');
const { appointmentValidator } = require('../validators');

// POST /api/appointments — patient books
router.post('/', auth, requireRole('patient'), appointmentValidator, async (req, res, next) => {
  try {
    const { doctor, date, time, reason } = req.body;

    // Check no duplicate booking same doctor/date/time
    const conflict = await Appointment.findOne({
      doctor,
      date: new Date(date),
      time,
      status: { $in: ['pending', 'confirmed'] }
    });
    if (conflict) {
      return res.status(409).json({ error: 'That slot is already booked. Please choose another time.' });
    }

    const appt = await Appointment.create({
      patient: req.user._id, doctor, date, time, reason
    });

    const populated = await appt.populate('doctor', 'name specialty');
    res.status(201).json(populated);
  } catch (err) { next(err); }
});

// GET /api/appointments/my — patient's own appointments (paginated)
router.get('/my', auth, requireRole('patient'), async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const [appointments, total] = await Promise.all([
      Appointment.find({ patient: req.user._id })
        .populate('doctor', 'name specialty')
        .sort({ date: -1 })
        .skip(skip)
        .limit(limit),
      Appointment.countDocuments({ patient: req.user._id })
    ]);

    res.json({ appointments, total, page, pages: Math.ceil(total / limit) });
  } catch (err) { next(err); }
});

// GET /api/appointments/doctor — doctor's appointments (paginated)
router.get('/doctor', auth, requireRole('doctor'), async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    const { status } = req.query;

    const filter = { doctor: req.user._id };
    if (status) filter.status = status;

    const [appointments, total] = await Promise.all([
      Appointment.find(filter)
        .populate('patient', 'name email phone dateOfBirth')
        .sort({ date: 1 })
        .skip(skip)
        .limit(limit),
      Appointment.countDocuments(filter)
    ]);

    res.json({ appointments, total, page, pages: Math.ceil(total / limit) });
  } catch (err) { next(err); }
});

// PUT /api/appointments/:id — doctor updates status/notes
router.put('/:id', auth, requireRole('doctor'), async (req, res, next) => {
  try {
    const { status, notes } = req.body;
    const appt = await Appointment.findOneAndUpdate(
      { _id: req.params.id, doctor: req.user._id },
      { status, notes },
      { new: true, runValidators: true }
    ).populate('patient', 'name email');

    if (!appt) return res.status(404).json({ error: 'Appointment not found' });
    res.json(appt);
  } catch (err) { next(err); }
});

// PATCH /api/appointments/:id/cancel — patient cancels own appointment
router.patch('/:id/cancel', auth, requireRole('patient'), async (req, res, next) => {
  try {
    const appt = await Appointment.findOneAndUpdate(
      { _id: req.params.id, patient: req.user._id, status: { $in: ['pending', 'confirmed'] } },
      { status: 'cancelled' },
      { new: true }
    );
    if (!appt) return res.status(404).json({ error: 'Appointment not found or cannot be cancelled' });
    res.json(appt);
  } catch (err) { next(err); }
});

module.exports = router;
