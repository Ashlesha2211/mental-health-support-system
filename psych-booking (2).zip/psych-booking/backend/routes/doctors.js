const router = require('express').Router();
const User = require('../models/User');
const { auth } = require('../middleware/auth');

// GET /api/doctors — list all doctors (any authenticated user)
router.get('/', auth, async (req, res, next) => {
  try {
    const { specialty } = req.query;
    const filter = { role: 'doctor', isActive: true };
    if (specialty) filter.specialty = { $regex: specialty, $options: 'i' };

    const doctors = await User.find(filter, 'name specialty').sort({ name: 1 });
    res.json(doctors);
  } catch (err) { next(err); }
});

// GET /api/doctors/:id — get one doctor's profile
router.get('/:id', auth, async (req, res, next) => {
  try {
    const doctor = await User.findOne(
      { _id: req.params.id, role: 'doctor' },
      'name specialty createdAt'
    );
    if (!doctor) return res.status(404).json({ error: 'Doctor not found' });
    res.json(doctor);
  } catch (err) { next(err); }
});

module.exports = router;
