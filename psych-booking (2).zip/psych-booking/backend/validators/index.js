const { body, validationResult } = require('express-validator');

// Middleware to check validation results
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      error: 'Validation failed',
      details: errors.array().map(e => ({ field: e.path, message: e.msg }))
    });
  }
  next();
};

// Auth validators
const registerValidator = [
  body('name').trim().isLength({ min: 2, max: 80 }).withMessage('Name must be 2–80 characters'),
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    .matches(/[A-Z]/).withMessage('Password must contain an uppercase letter')
    .matches(/\d/).withMessage('Password must contain a number'),
  body('role').isIn(['patient', 'doctor']).withMessage('Role must be patient or doctor'),
  body('specialty').if(body('role').equals('doctor'))
    .notEmpty().withMessage('Specialty required for doctors'),
  validate
];

const loginValidator = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').notEmpty().withMessage('Password required'),
  validate
];

// Appointment validators
const appointmentValidator = [
  body('doctor').isMongoId().withMessage('Valid doctor ID required'),
  body('date').isISO8601().withMessage('Valid date required'),
  body('time').matches(/^([01]\d|2[0-3]):([0-5]\d)$/).withMessage('Time must be HH:MM format'),
  body('reason').trim().isLength({ min: 5, max: 500 }).withMessage('Reason must be 5–500 characters'),
  validate
];

// Prescription validators
const prescriptionValidator = [
  body('patient').isMongoId().withMessage('Valid patient ID required'),
  body('medications').isArray({ min: 1 }).withMessage('At least one medication required'),
  body('medications.*.name').trim().notEmpty().withMessage('Medication name required'),
  body('medications.*.dosage').trim().notEmpty().withMessage('Dosage required'),
  body('medications.*.frequency').trim().notEmpty().withMessage('Frequency required'),
  body('medications.*.duration').trim().notEmpty().withMessage('Duration required'),
  validate
];

module.exports = {
  registerValidator,
  loginValidator,
  appointmentValidator,
  prescriptionValidator
};
