/**
 * Seed script — populates the database with demo doctors and a test patient
 * Run: node seed.js
 */

const mongoose = require('mongoose');
const User = require('./models/User');
require('dotenv').config();

const doctors = [
  { name: 'Dr. Aisha Kapoor', email: 'aisha.kapoor@mindcare.com', password: 'Doctor123', role: 'doctor', specialty: 'Adult Psychiatry' },
  { name: 'Dr. Rohan Mehta', email: 'rohan.mehta@mindcare.com', password: 'Doctor123', role: 'doctor', specialty: 'Child & Adolescent Psychiatry' },
  { name: 'Dr. Priya Nair', email: 'priya.nair@mindcare.com', password: 'Doctor123', role: 'doctor', specialty: 'Forensic Psychiatry' },
  { name: 'Dr. Sanjay Rao', email: 'sanjay.rao@mindcare.com', password: 'Doctor123', role: 'doctor', specialty: 'Addiction Psychiatry' }
];

const patient = {
  name: 'Demo Patient',
  email: 'patient@demo.com',
  password: 'Patient123',
  role: 'patient'
};

async function seed() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('Connected to MongoDB');

  await User.deleteMany({ email: { $in: [...doctors.map(d => d.email), patient.email] } });

  for (const doc of doctors) {
    await User.create(doc);
    console.log(`✅ Created doctor: ${doc.name}`);
  }

  await User.create(patient);
  console.log(`✅ Created patient: ${patient.name}`);

  console.log('\n📋 Demo credentials:');
  console.log('Patient  →  patient@demo.com  /  Patient123');
  console.log('Doctor   →  aisha.kapoor@mindcare.com  /  Doctor123');

  await mongoose.disconnect();
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
