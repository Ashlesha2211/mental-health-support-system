const request = require('supertest');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const app = require('../server');
const User = require('../models/User');

let mongod;

beforeAll(async () => {
  mongod = await MongoMemoryServer.create();
  await mongoose.connect(mongod.getUri());
  process.env.JWT_SECRET = 'test_secret_key_for_jest';
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongod.stop();
});

afterEach(async () => {
  await User.deleteMany({});
});

describe('POST /api/auth/register', () => {
  it('should register a new patient', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Test Patient',
      email: 'patient@test.com',
      password: 'Password1',
      role: 'patient'
    });
    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty('token');
    expect(res.body.user.role).toBe('patient');
  });

  it('should register a doctor with specialty', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Dr. Smith',
      email: 'doctor@test.com',
      password: 'Password1',
      role: 'doctor',
      specialty: 'Psychiatry'
    });
    expect(res.status).toBe(201);
    expect(res.body.user.role).toBe('doctor');
  });

  it('should reject duplicate email', async () => {
    await User.create({
      name: 'Existing', email: 'exists@test.com',
      password: 'Password1', role: 'patient'
    });
    const res = await request(app).post('/api/auth/register').send({
      name: 'Dupe', email: 'exists@test.com',
      password: 'Password1', role: 'patient'
    });
    expect(res.status).toBe(409);
  });

  it('should reject weak password', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Test', email: 'test@test.com',
      password: 'weak', role: 'patient'
    });
    expect(res.status).toBe(422);
    expect(res.body).toHaveProperty('details');
  });

  it('should require specialty for doctor', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Dr. No Spec', email: 'doc@test.com',
      password: 'Password1', role: 'doctor'
    });
    expect(res.status).toBe(422);
  });
});

describe('POST /api/auth/login', () => {
  beforeEach(async () => {
    await request(app).post('/api/auth/register').send({
      name: 'Test User', email: 'user@test.com',
      password: 'Password1', role: 'patient'
    });
  });

  it('should login with correct credentials', async () => {
    const res = await request(app).post('/api/auth/login').send({
      email: 'user@test.com', password: 'Password1'
    });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('token');
  });

  it('should reject wrong password', async () => {
    const res = await request(app).post('/api/auth/login').send({
      email: 'user@test.com', password: 'WrongPass1'
    });
    expect(res.status).toBe(401);
  });

  it('should reject non-existent user', async () => {
    const res = await request(app).post('/api/auth/login').send({
      email: 'nobody@test.com', password: 'Password1'
    });
    expect(res.status).toBe(401);
  });
});

describe('GET /api/auth/me', () => {
  it('should return current user with valid token', async () => {
    const reg = await request(app).post('/api/auth/register').send({
      name: 'Me Test', email: 'me@test.com',
      password: 'Password1', role: 'patient'
    });
    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${reg.body.token}`);
    expect(res.status).toBe(200);
    expect(res.body.user.email).toBe('me@test.com');
  });

  it('should reject request without token', async () => {
    const res = await request(app).get('/api/auth/me');
    expect(res.status).toBe(401);
  });
});
