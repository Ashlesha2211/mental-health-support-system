# 🧠 MindCare — Psychiatric Booking Platform

A full-stack MERN application for psychiatric appointment booking, prescription management, and patient-doctor record keeping.

> Built with MongoDB · Express.js · React · Node.js · Docker · GitHub Actions · Fly.io · Vercel

---

## ✨ Features

| Feature | Patient | Doctor |
|---|---|---|
| Register / Login (JWT) | ✅ | ✅ |
| Role-based access control | ✅ | ✅ |
| Book appointments | ✅ | — |
| View & cancel appointments | ✅ | — |
| View prescriptions | ✅ | — |
| Manage appointments (confirm/complete/cancel) | — | ✅ |
| Add clinical notes | — | ✅ |
| Issue multi-drug prescriptions | — | ✅ |
| View prescription history | — | ✅ |

---

## 🏗️ Architecture

```
psych-booking/
├── backend/                 # Node.js + Express REST API
│   ├── models/              # Mongoose schemas (User, Appointment, Prescription)
│   ├── routes/              # REST endpoints
│   ├── middleware/          # JWT auth, role guard
│   ├── validators/          # express-validator rules
│   ├── tests/               # Jest + Supertest integration tests
│   ├── seed.js              # Demo data seeder
│   ├── Dockerfile           # Multi-stage production image
│   └── fly.toml             # Fly.io deployment config
├── frontend/                # React + Vite SPA
│   ├── src/
│   │   ├── pages/           # Home, Login, Register, PatientDashboard, DoctorDashboard
│   │   ├── hooks/           # useAuth context
│   │   └── utils/           # Axios instance with interceptors
│   └── Dockerfile           # Multi-stage production image
├── docker-compose.yml       # Full local stack (mongo + backend + frontend)
└── .github/workflows/       # CI/CD: test → build → deploy
    └── deploy.yml
```

---

## 🚀 Quick Start (Local)

### Option A — Docker Compose (Recommended, one command)

```bash
git clone https://github.com/yourusername/psych-booking.git
cd psych-booking
docker-compose up --build
```

Then open:
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000/api
- Health check: http://localhost:5000/api/health

### Option B — Manual

```bash
# 1. Backend
cd backend
cp .env.example .env       # fill in MONGO_URI and JWT_SECRET
npm install
npm run dev

# 2. Frontend (new terminal)
cd frontend
npm install
npm run dev
```

### Seed Demo Data

```bash
cd backend
node seed.js
```

**Demo credentials:**
| Role | Email | Password |
|---|---|---|
| Patient | patient@demo.com | Patient123 |
| Doctor | aisha.kapoor@mindcare.com | Doctor123 |

---

## 🌐 Deployment

### Prerequisites
- [MongoDB Atlas](https://www.mongodb.com/atlas) free M0 cluster
- [Fly.io](https://fly.io) account
- [Vercel](https://vercel.com) account

### 1. Deploy Backend → Fly.io

```bash
cd backend
flyctl auth login
flyctl launch          # creates fly.toml, choose "sin" region (Singapore)
flyctl secrets set \
  MONGO_URI="mongodb+srv://..." \
  JWT_SECRET="your_32+_char_secret" \
  CLIENT_URL="https://your-frontend.vercel.app"
flyctl deploy
```

### 2. Deploy Frontend → Vercel

```bash
cd frontend
npx vercel
# Set environment variable: VITE_API_URL = https://your-backend.fly.dev/api
```

### 3. GitHub Actions (Auto CI/CD)

Add these secrets in GitHub → Settings → Secrets:

| Secret | Where to get it |
|---|---|
| `FLY_API_TOKEN` | `flyctl auth token` |
| `VERCEL_TOKEN` | Vercel → Settings → Tokens |
| `VITE_API_URL` | Your Fly.io backend URL + `/api` |

Every push to `main` will now: **run tests → build → deploy automatically**.

---

## 🔒 Security Implementation

- **Helmet.js** — sets 11 security HTTP headers
- **CORS** — origin-restricted to `CLIENT_URL` env var
- **Rate Limiting** — 100 req/15min general, 10 req/15min on auth routes
- **bcrypt (cost 12)** — password hashing
- **JWT (7d expiry)** — stateless authentication
- **express-validator** — server-side input validation on all routes
- **Role-based access** — patient/doctor routes fully separated via middleware
- **Non-root Docker user** — container runs as `nodejs` user, not root

---

## 🧪 Testing

```bash
cd backend
npm test              # run all tests
npm run test:coverage # with coverage report
```

Tests cover:
- User registration (success, duplicate, weak password, missing specialty)
- User login (success, wrong password, non-existent user)
- Auth middleware (valid token, no token, expired token)

---

## 📡 API Reference

| Method | Endpoint | Auth | Role |
|---|---|---|---|
| POST | `/api/auth/register` | — | — |
| POST | `/api/auth/login` | — | — |
| GET | `/api/auth/me` | ✅ | any |
| GET | `/api/doctors` | ✅ | any |
| POST | `/api/appointments` | ✅ | patient |
| GET | `/api/appointments/my` | ✅ | patient |
| PATCH | `/api/appointments/:id/cancel` | ✅ | patient |
| GET | `/api/appointments/doctor` | ✅ | doctor |
| PUT | `/api/appointments/:id` | ✅ | doctor |
| POST | `/api/prescriptions` | ✅ | doctor |
| GET | `/api/prescriptions/my` | ✅ | patient |
| GET | `/api/prescriptions/doctor` | ✅ | doctor |
| GET | `/api/health` | — | — |

---

## 🛠️ Tech Stack

**Backend:** Node.js 20, Express 4, MongoDB 7, Mongoose 7, JWT, bcryptjs, express-validator, Helmet, Morgan, express-rate-limit

**Frontend:** React 18, Vite 5, React Router 6, TanStack Query v5, React Hook Form, Axios

**DevOps:** Docker (multi-stage builds), Docker Compose, GitHub Actions, Fly.io, Vercel, MongoDB Atlas

---

## 📄 License

MIT
